from flask import Flask, render_template
from flask_bootstrap import Bootstrap
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from werkzeug.exceptions import HTTPException


db = SQLAlchemy()
login_manager = LoginManager()


def create_app() -> Flask:
    app = Flask(__name__)

    app.secret_key = 'some_very_secret_value'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///travel.sqlite'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['UPLOAD_FOLDER'] = 'static/image'

    login_manager.login_view = 'authentication.login'
    login_manager.init_app(app)

    bootstrap = Bootstrap(app)

    db.init_app(app)

    from AuctionSite.authentication import authentication_blueprint
    from AuctionSite.views import main_blueprint
    from AuctionSite.property import property_blueprint
    from AuctionSite.watchlist import watchlist_blueprint
    app.register_blueprint(main_blueprint)
    app.register_blueprint(property_blueprint)
    app.register_blueprint(authentication_blueprint)
    app.register_blueprint(watchlist_blueprint)

    @app.errorhandler(Exception)
    def handle_exception(e):
        # pass through HTTP errors
        if isinstance(e, HTTPException):
            return render_template('custom_error.html')

        # now you're handling non-HTTP exceptions only
        return render_template("500_generic.html", e=e), 500


    return app
