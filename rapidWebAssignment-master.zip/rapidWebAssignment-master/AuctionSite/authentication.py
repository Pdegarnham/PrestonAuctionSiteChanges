from flask import Blueprint, render_template, session, redirect, url_for, flash
from AuctionSite.forms import LoginForm, RegisterForm
from AuctionSite.models.user import User
from AuctionSite import db
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user

authentication_blueprint = Blueprint(
    'authentication', __name__, url_prefix='/authentication')


@authentication_blueprint.route('/login', methods=['GET', 'POST'])
def login():
    login_form_instance = LoginForm()
    if login_form_instance.validate_on_submit():
        user = User.query.filter_by(
            name=login_form_instance.user_name.data).first()

        if not user:
            flash('username or password incorrect')
            return redirect(url_for('authentication.login'))

        if not check_password_hash(user.password_hash, login_form_instance.password.data):
            flash('username or password incorrect')
            return redirect(url_for('authentication.login'))

        login_user(user)
        return redirect(url_for('main.index_controller'))

    return render_template('authentication/login.html', form=login_form_instance,
                           heading='Login')


@authentication_blueprint.route('/register', methods=['GET', 'POST'])
def register():
    register_form_instance = RegisterForm()
    if register_form_instance.validate_on_submit():
        # check if username is unique
        existing_user = User.query.filter_by(
            name=register_form_instance.user_name.data).first()

        if existing_user:
            flash('user already exists')
            return redirect(url_for('authentication.register'))

        user = User()
        user.email = register_form_instance.email_id.data
        user.name = register_form_instance.user_name.data
        user.address = register_form_instance.address.data
        user.contactNumber = register_form_instance.contactNumber.data
        user.password_hash = generate_password_hash(
            register_form_instance.password.data)
        db.session.add(user)
        db.session.commit()

        return redirect(url_for('authentication.login'))

    return render_template('authentication/register.html', form=register_form_instance,
                           heading='Register')


@authentication_blueprint.route('/logout')
def logout():
    session.clear()
    return render_template('authentication/logout.html',
                           heading='Logout')
