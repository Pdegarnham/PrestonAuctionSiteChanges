from flask import Blueprint, render_template, request, session, url_for
from AuctionSite import property

main_blueprint = Blueprint('main', __name__)


#Preston Change

@main_blueprint.route('/<category>', methods=['GET', 'POST'])
def byCategory(category):
    from AuctionSite.models.property import Property
    from AuctionSite.models.bid import Bid
    properties = Property.query.all()
    bids = Bid
    # if the form was successfully submitted, access form data
    properties = Property.query.filter(
        Property.propertyType.like(category)).all()
    # properties = Property.query.filter_by(propertyType.like('%a%')).all()
    return render_template('index.html', properties=properties, bids=bids)

@main_blueprint.route('/')
def index_controller():
    from AuctionSite.models.property import Property
    from AuctionSite.models.bid import Bid
    properties = Property.query.all()
    bids = Bid
    return render_template('index.html', properties=properties, bids=bids)

#End Preston Change
