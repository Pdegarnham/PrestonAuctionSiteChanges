from flask import Blueprint, render_template, request, url_for, redirect, flash
from AuctionSite.models.property import Property
from AuctionSite.models.watchlist import Watchlist
from datetime import datetime
import os
from AuctionSite import db
from flask_login import login_required, current_user

watchlist_blueprint = Blueprint(
    'watchlist', __name__, url_prefix='/watchlist')


@watchlist_blueprint.route('/', methods=['GET', 'POST'])
def base():
    return redirect(url_for('authentication.login'))


@watchlist_blueprint.route('/<id>', methods=['GET', 'POST'])
@login_required
def show(id):
    # destination_instace = database_get_destination_details()
    watchlist = Watchlist.query.filter_by(userId=id).all()
    return render_template('watchlist/show.html', watchlist=watchlist)


@watchlist_blueprint.route('remove/<id>', methods=['GET', 'POST'])
def remove(id):
    # destination_instace = database_get_destination_details()
    print(id)
    Watchlist.query.filter_by(propertyId=id, userId=current_user.id).delete()
    db.session.commit()
    return redirect(url_for('watchlist.show', id=current_user.id))
