
from AuctionSite import db
from AuctionSite.models.bid import Bid


class Property(db.Model):
    __tablename__ = 'properties'
    id = db.Column(db.Integer, primary_key=True)
    # address
    propertyAddress = db.Column(db.String(80), nullable=False)
    # description
    propertyDescription = db.Column(db.String(200), nullable=False)
    # property type
    propertyType = db.Column(db.String(80), nullable=False)
    # number of beds
    numberOfBedrooms = db.Column(db.String(80), nullable=False)
    # number of bathrooms
    numberOfBathrooms = db.Column(db.String(80), nullable=False)
    # contact details of lister
    contactDetails = db.Column(db.String(80), nullable=False)
    # start bd set by user
    startingBid = db.Column(db.Integer(), nullable=False)
    # winning bid(always highest)
    winningBid = db.Column(db.Integer(), nullable=False)
    # image for property
    image = db.Column(db.String(400), nullable=False)
    # bool open or closed
    auctionOpen = db.Column(db.Boolean, default=True)
    # user who put it up
    userId = db.Column(db.Integer, db.ForeignKey('users.id'))

    # bids
    bids = db.relationship('Bid', backref='property')
    comments = db.relationship('Comment', backref='property')

    def __repr__(self):  # string print method
        return "<Name: {}>".format(self.propertyAddress)
