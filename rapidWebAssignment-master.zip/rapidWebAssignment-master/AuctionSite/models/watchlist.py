from AuctionSite import db


class Watchlist(db.Model):
    __tablename__ = 'watchlist'
    id = db.Column(db.Integer, primary_key=True)
    # user id for watchlist
    userId = db.Column(db.Integer, db.ForeignKey('users.id'))
    # property added to watchlist
    propertyId = db.Column(db.Integer, db.ForeignKey('properties.id'))
    property = db.relationship('Property', backref='watchlist')
