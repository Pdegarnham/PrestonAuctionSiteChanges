from AuctionSite import db
from flask_login import UserMixin
from AuctionSite import login_manager
from AuctionSite.models.property import Property


class User(db.Model, UserMixin):

    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), index=True, unique=True, nullable=False)
    email = db.Column(db.String(100), nullable=False)
    contactNumber = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(100), nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    listings = db.relationship('Property', backref='user')
    comments = db.relationship('Comment', backref='user')
    bids = db.relationship('Bid', backref='user')


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))
