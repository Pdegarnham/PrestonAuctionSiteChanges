from datetime import datetime
from AuctionSite import db


class Bid(db.Model):
    __tablename__ = 'bid'
    id = db.Column(db.Integer, primary_key=True)
    bidAmount = db.Column(db.Integer())
    created_at = db.Column(db.DateTime, default=datetime.now())

    # add the foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    property_id = db.Column(db.Integer,  db.ForeignKey('properties.id'))

    def __repr__(self):
        return "<Bid: {} For:{} >".format(self.bidAmount, self.property_id)
