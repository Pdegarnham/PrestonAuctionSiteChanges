from flask import Blueprint, render_template, request, url_for, redirect, flash
from AuctionSite.models.property import Property
from AuctionSite.models.bid import Bid
from AuctionSite.models.watchlist import Watchlist
from AuctionSite.models.comment import Comment
from AuctionSite.forms import PropertyForm
from AuctionSite.forms import BidForm
from AuctionSite.forms import CommentForm
from datetime import datetime
from werkzeug.utils import secure_filename
import os
from AuctionSite import db
from flask_login import login_required, current_user

property_blueprint = Blueprint(
    'property', __name__, url_prefix='/property')


@property_blueprint.route('/myListings/<id>', methods=['GET', 'POST'])
def myListings(id):
    # destination_instace = database_get_destination_details()

    listings = Property.query.filter_by(userId=id).all()
    return render_template('property/myListings.html', listings=listings)


@property_blueprint.route('/closeAuction/<id>', methods=['GET', 'POST'])
def closeAuction(id):
    # destination_instace = database_get_destination_details()
    property = Property.query.filter_by(id=id).first()
    property.auctionOpen = False
    db.session.commit()
    return redirect(url_for('property.myListings', id=current_user.id))


@property_blueprint.route('/<id>', methods=['GET', 'POST'])
def show(id):
    # destination_instace = database_get_destination_details()
    bid_form_instance = BidForm()
    comment_form_instance = CommentForm()
    property = Property.query.filter_by(id=id).first()
    return render_template('property/show.html', property=property, form=bid_form_instance, commentForm=comment_form_instance)


@property_blueprint.route('/<id>/bid', methods=['POST'])
@login_required
def bid(id):
    bid_form_instance = BidForm()
    if bid_form_instance.validate_on_submit():  # this is true only in case of POST method

        user = current_user.id
        property = Property.query.filter_by(id=id).first()
        winnigBid = Property.query.filter_by(
            id=id).first().winningBid

        if winnigBid > bid_form_instance.bid.data:
            flash('bid must be higher than current bid')

        else:
            # read the comment from the form
            bid = Bid(bidAmount=bid_form_instance.bid.data,
                      user_id=user,
                      property_id=id)
            # here the back-referencing works - comment.destination is set
            # and the link is created
            db.session.add(bid)
            property.winningBid = bid_form_instance.bid.data
            db.session.commit()

    return redirect(url_for('property.show', id=id))


@property_blueprint.route('/<id>/watchlistAdd', methods=['GET', 'POST'])
@login_required
def watchlistAdd(id):
    user = current_user.id
    property = Property.query.filter_by(id=id).first()

    existingWatchlistItem = Watchlist.query.filter_by(
        userId=user, propertyId=id).first()

    if existingWatchlistItem:
        flash('Property is already in your watchlist')
        return redirect(url_for('property.show', id=id))
    watchlistItem = Watchlist(userId=user, propertyId=id, property=property)
    db.session.add(watchlistItem)
    db.session.commit()
    return redirect(url_for('watchlist.show', id=user))


@property_blueprint.route('/browse', methods=['GET', 'POST'])
def browse():
    # if the form was successfully submitted, access form data
    properties = Property.query.all()
    return render_template('property/browse.html', properties=properties)

@property_blueprint.route('/landing', methods=['GET', 'POST'])
def landing():
    # if the form was successfully submitted, access form data
    properties = Property.query.all()
    return render_template('property/browse.html', properties=properties)


@property_blueprint.route('/browse/<category>', methods=['GET', 'POST'])
def browseCategory(category):
    # if the form was successfully submitted, access form data
    properties = Property.query.filter(
        Property.propertyType.like(category)).all()
    # properties = Property.query.filter_by(propertyType.like('%a%')).all()
    return render_template('property/browse.html', properties=properties)


@ property_blueprint.route('/create', methods=['GET', 'POST'])
@ login_required
def create():

    property_form_instance = PropertyForm()
    if property_form_instance.validate_on_submit():
        target_folder = 'static/images'
        file = property_form_instance.image.data
        BASE_PATH = os.path.dirname(__file__)
        full_path = os.path.join(
            BASE_PATH, target_folder, secure_filename(file.filename))
        file.save(full_path)
        relative_path = '/' + target_folder + \
            '/' + secure_filename(file.filename)

        # if the form was successfully submitted, access form data
        property = Property(propertyAddress=property_form_instance.propertyAddress.data,
                            propertyDescription=property_form_instance.propertyDescription.data,
                            propertyType=property_form_instance.propertyType.data,
                            numberOfBedrooms=property_form_instance.numberOfBedrooms.data,
                            numberOfBathrooms=property_form_instance.numberOfBathrooms.data,
                            image=relative_path,
                            startingBid=property_form_instance.startingBid.data,
                            winningBid=property_form_instance.startingBid.data,
                            userId=current_user.id,
                            contactDetails=property_form_instance.contactDetails.data)
        # add the object to the db session
        db.session.add(property)
        # commit to the database
        db.session.commit()
        return redirect(url_for('property.create'))

    return render_template('property/create.html', form=property_form_instance)


@property_blueprint.route('/<id>/comment', methods=['POST'])
@login_required
def comment(id):
    comment_form_instance = CommentForm()
    if comment_form_instance.validate_on_submit():  # this is true only in case of POST method
        property = Property.query.filter_by(id=id).first()
        user = current_user
        # read the comment from the form
        comment = Comment(text=comment_form_instance.text.data,
                          property=property,
                          user=user)
        # here the back-referencing works - comment.destination is set
        # and the link is created
        db.session.add(comment)
        db.session.commit()

    return redirect(url_for('property.show', id=id))
