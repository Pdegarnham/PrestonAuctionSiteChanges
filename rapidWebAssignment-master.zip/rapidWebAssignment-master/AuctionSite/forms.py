from flask_wtf import FlaskForm
from wtforms.fields import TextAreaField, SubmitField, StringField, PasswordField, IntegerField, SelectField
from wtforms.validators import InputRequired, Length, Email, EqualTo
from flask_wtf.file import FileRequired, FileField, FileAllowed

# creates the login information


class LoginForm(FlaskForm):
    user_name = StringField("User Name", validators=[
                            InputRequired('Enter user name')])
    password = PasswordField("Password", validators=[
                             InputRequired('Enter user password')])
    submit = SubmitField("Login")


class RegisterForm(FlaskForm):
    user_name = StringField("User Name", validators=[
                            InputRequired("Please enter a user name")])
    email_id = StringField("Email Address", validators=[InputRequired(
        "Please enter a email"), Email("Please enter a valid email")])
    contactNumber = StringField("Contact Number", validators=[
        InputRequired("Please enter a contact number")])
    address = StringField("Address", validators=[
        InputRequired("Please enter an address")])
    # linking two fields - password should be equal to data entered in confirm
    password = PasswordField("Password", validators=[InputRequired(),
                                                     EqualTo('confirm', message="Passwords should match")])
    confirm = PasswordField("Confirm Password")
    # submit button
    submit = SubmitField("Register")


class PropertyForm(FlaskForm):
    allowed_files = {'png', 'jpg', 'JPG', 'PNG'}

    propertyAddress = StringField('Property Address', validators=[
        InputRequired('Address is required')])
    propertyDescription = TextAreaField('Property Description',
                                        validators=[InputRequired('Descripion is required'),
                                                    Length(min=10, max=300, message='Description is to short or to long')])
    propertyType = SelectField('Property Type', choices=[('Apartments', 'Apartments'), (
        'Single-Family Home', 'Single-Family Home'), ('Co-Op', 'Co-Op'), ('Townhouse', 'Townhouse'), ('Multi-Family Home', 'Multi-Family Home')])
    numberOfBedrooms = IntegerField('No. Of Bedrooms', validators=[
        InputRequired('Bedrooms is required')])
    numberOfBathrooms = IntegerField('No. Of Bathrooms', validators=[
        InputRequired('Bedrooms is required')])
    image = FileField('Image', validators=[FileRequired(
        'Image is Required'), FileAllowed(allowed_files, message='only supports png, jpg, JPG, PNG')])
    startingBid = IntegerField('Starting Bid', validators=[
        InputRequired('Starting Bid Required')])
    contactDetails = IntegerField('Contact Details', validators=[
        InputRequired('Contact is required')])
   # image = FileField('Cover Image', validators=[FileRequired(
   #     'Image is Required'), FileAllowed(allowed_files, message='only supports png, jpg, JPG, PNG')])
    submit = SubmitField("Create")


class BidForm(FlaskForm):
    bid = IntegerField('Bid Amount', validators=[
        InputRequired('Starting Bid Required')])
    submit = SubmitField("Submit Bid")


class CommentForm(FlaskForm):
    text = TextAreaField('', [InputRequired("Please enter a comment")])
    submit = SubmitField('Post Comment')
